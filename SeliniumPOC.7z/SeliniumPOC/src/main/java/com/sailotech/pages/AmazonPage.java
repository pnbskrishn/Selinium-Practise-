package com.sailotech.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmazonPage {
	WebDriver driver;

	public AmazonPage(WebDriver driver) {
		this.driver = driver;

	}

	@FindBy(xpath = "//*[@id=\"twotabsearchtextbox\"]")
	private WebElement searchBox;

	@FindBy(id = "priceblock_ourprice")
	private WebElement priceText;

	public void setProduct(String productName) {
		searchBox.sendKeys(productName);
	}

	public WebElement getSearchBox() {
		return searchBox;
	}

	public void setSearchBox(WebElement searchBox) {
		this.searchBox = searchBox;
	}

	public WebElement getPriceText() {
		return priceText;
	}

	public void setPriceText(WebElement priceText) {
		this.priceText = priceText;
	}

}
