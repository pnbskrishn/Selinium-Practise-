/**
 * 
 */
package com.sailotech.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FlipKartPage {
	
	 WebDriver driver; 
	  
	    public FlipKartPage(WebDriver driver) { 
	        this.driver = driver; 
	     
	    } 
	    @FindBy(className =  
	            "LM6RPg") 
	    public WebElement searchBox; 
	    
	    @FindBy(className =  
	            "_6BWGkk") 
	    public WebElement priceText; 
	    
	    @FindBy(xpath =  
	            "//*[@class='_2AkmmA _29YdH8']")
		 
		public WebElement loginButton; 
	    
	 
	    public void setProduct(String productName) { 
	    	searchBox.sendKeys(productName); 
	        }


		public WebElement getSearchBox() {
			return searchBox;
		}


		public void setSearchBox(WebElement searchBox) {
			this.searchBox = searchBox;
		}


		public WebElement getPriceText() {
			return priceText;
		}


		public void setPriceText(WebElement priceText) {
			this.priceText = priceText;
		}


		public WebElement getLoginButton() {
			return loginButton;
		}


		public void setLoginButton(WebElement loginButton) {
			this.loginButton = loginButton;
		} 
	    

}
