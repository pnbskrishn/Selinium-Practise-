package com.sailotech.pages;

import org.openqa.selenium.WebDriver;

public class HomePageThreadLocal {

   /* private static ThreadLocal<AmazonHomePage> homePage = new ThreadLocal<AmazonHomePage>();

    public HomePageThreadLocal(WebDriver driver,Object className) {
    	homePage.set(new AmazonHomePage(driver));
    }

    public AmazonHomePage gethomePage() {
        return this.homePage.get();
    }*/
}
