package com.sailotech.tests;


public class CommonUtils {
	
	public static long PAGE_LOAD_TIMEOUT = 30;
	public static long IMPLICIT_WAIT = 10;
	public static String AMAZON_URL = "https://www.amazon.in/";
	public static String FLIPKART_URL = "https://www.flipkart.com/";
	public static String TRIPADVISOR_URL =  "https://www.tripadvisor.in/";
	
	

}
