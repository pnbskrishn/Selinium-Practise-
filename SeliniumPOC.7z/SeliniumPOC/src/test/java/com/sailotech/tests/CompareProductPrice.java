/**
 * 
 */
package com.sailotech.tests;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sailotech.pages.AmazonPage;
import com.sailotech.pages.FlipKartPage;


public class CompareProductPrice {

	static WebDriver driver;
	
	 private static final Logger logger = LoggerFactory.getLogger(CompareProductPrice.class);

	

	@BeforeMethod
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\src\\test\\java\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(CommonUtils.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.manage().window().maximize();

	}
	@Test
	public void verifyProductCostTest() throws InterruptedException, IOException {
		String product = "iPhone XR (64GB) - Yellow";
		
		
		Double amazonPrice =getAmazonProductCost(product);
		Double flipKartPrice =getflipCartProductCost(product);
		
		if(amazonPrice != flipKartPrice){
		if (amazonPrice < flipKartPrice){
			logger.info("Amazon Price is lower");
			System.out.println("value of price is lower Amazon");
			Assert.assertTrue(amazonPrice < flipKartPrice, " value of price is lower Amazon");
			
		}else  {
			logger.info("Flip kart Price is higher");
			System.out.println("value of price is lower in Flipkart");
			Assert.assertTrue(amazonPrice < flipKartPrice, "value of price is lower in Flipkart");
			
		} }
		else{
			System.out.println("value of price is Same in Flipkart");
			assertTrue(false,"Both Values are same ");
			
		}
		driver.close();
	}
	
	//@Test()
	public Double getAmazonProductCost(String product) {
	driver.get(CommonUtils.AMAZON_URL);
	AmazonPage amazonPage = PageFactory.initElements(driver, AmazonPage.class);
	amazonPage.setProduct(product);
	amazonPage.getSearchBox().sendKeys(Keys.ENTER);
	driver.findElement(By.xpath("//a[contains(.,'" + product + "')]")).click();
	String amazonAmount = amazonPage.getPriceText().getText();
	logger.info("AmazonPrice" + amazonAmount);
	return getValueFromString(amazonAmount);
	}
	
	//@Test
	public Double getflipCartProductCost(String product) {
		driver.get(CommonUtils.FLIPKART_URL);
		FlipKartPage flipKartPage = PageFactory.initElements(driver, FlipKartPage.class);
		if (flipKartPage.loginButton.isDisplayed()) {
			flipKartPage.loginButton.click();
		}
		flipKartPage.setProduct(product);
		flipKartPage.searchBox.sendKeys(Keys.ENTER);
		String flipKartamount = flipKartPage.priceText.getText();

		logger.info("FlipKart Price" + flipKartamount);
		 return getValueFromString(flipKartamount);
	}

	private Double getValueFromString(String amount) {
		String processedAmount = amount.replaceAll("[₹ ,]*", "");
		logger.info("processedamount" + processedAmount);
		Double amountValue = Double.parseDouble(processedAmount);
		return amountValue;

	}

}
